import { Component, OnInit } from '@angular/core';
import { ExampleService } from '../example.service';

@Component({
  selector: 'app-completed',
  templateUrl: './completed.component.html',
  styleUrls: ['./completed.component.scss']
})
export class CompletedComponent implements OnInit {
  ticket: [];
  constructor(private example: ExampleService) { }

  ngOnInit() {
    this.example.getTickets()
      .subscribe(data => {
        this.ticket = data;
      });
  }
}
