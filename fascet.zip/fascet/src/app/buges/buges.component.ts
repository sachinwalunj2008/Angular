import { Component, OnInit } from '@angular/core';
import { ExampleService } from '../example.service';

@Component({
  selector: 'app-buges',
  templateUrl: './buges.component.html',
  styleUrls: ['./buges.component.scss']
})
export class BugesComponent implements OnInit {
  ticket: [];
  constructor(private example: ExampleService) { }

  ngOnInit() {
    this.example.getTickets()
      .subscribe(data => {
        this.ticket = data;
      });
  }

}
