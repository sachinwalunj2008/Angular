import { Component, OnInit } from '@angular/core';
import { ExampleService } from '../example.service';

@Component({
  selector: 'app-inprogress',
  templateUrl: './inprogress.component.html',
  styleUrls: ['./inprogress.component.scss']
})
export class InprogressComponent implements OnInit {
  ticket: [];
  constructor(private example: ExampleService) { }

  ngOnInit() {
    this.example.getTickets()
      .subscribe(data => {
        this.ticket = data;
      });
  }

}
