import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { ExampleService } from './example.service';
import { HttpClientModule } from '@angular/common/http';
import { TaskComponent } from './task/task.component';
import { BugesComponent } from './buges/buges.component';
import { CompletedComponent } from './completed/completed.component';
import { InprogressComponent } from './inprogress/inprogress.component';
import { NotStartedComponent } from './not-started/not-started.component';



@NgModule({
  declarations: [
    AppComponent,
    TaskComponent,
    BugesComponent,
    CompletedComponent,
    InprogressComponent,
    NotStartedComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
  ],
  providers: [ExampleService],
  bootstrap: [AppComponent]
})
export class AppModule { }
