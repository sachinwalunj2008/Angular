import { Component, OnInit } from '@angular/core';
import { ExampleService } from '../example.service';

@Component({
  selector: 'app-not-started',
  templateUrl: './not-started.component.html',
  styleUrls: ['./not-started.component.scss']
})
export class NotStartedComponent implements OnInit {

  ticket: [];
  constructor(private example: ExampleService) { }

  ngOnInit() {
    this.example.getTickets()
      .subscribe(data => {
        this.ticket = data;
      });
  }

}
