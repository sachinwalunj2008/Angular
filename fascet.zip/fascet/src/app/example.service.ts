import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';


@Injectable({
  providedIn: 'root'
})
export class ExampleService {

  constructor(private readonly http: HttpClient) {
    this.getTickets().subscribe(data => {
      console.log(data);
    });
  }

  getTickets(): Observable<any> {
    return this.http.get<any>('./../assets/tickets.json');
  }

}
