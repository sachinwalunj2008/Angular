import { Component, OnInit } from '@angular/core';
import { ExampleService } from './example.service';
import { tick } from '@angular/core/testing';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss'],
})
export class AppComponent implements OnInit {
  title = 'fascet';
  ticket: [];
  taskNumber: number;
  bugesNumber: number;
  completed: number;
  inProgress: number;
  notStarted: number;

  constructor(private example: ExampleService) {
  }

  ngOnInit() {
    this.example.getTickets()
      .subscribe(data => {
        this.ticket = data;
        this.taskNumber = this.getNbOccur('1', this.ticket);
        this.bugesNumber = this.getNbOccur('2', this.ticket);

        this.completed = this.getStatusOccur('1', this.ticket);
        this.inProgress = this.getStatusOccur('2', this.ticket);
        this.notStarted = this.getStatusOccur('3', this.ticket);
      });
  }

  getNbOccur(Type: string, arr: any) {
    let occurs = 0;
    for (const i in arr) {
      if ('Type' in arr[i] && arr[i].Type === Type) { occurs++; }
    }
    return occurs;
    console.log(occurs);
  }

  getStatusOccur(Status: string, arr: any) {
    let occurs = 0;
    for (const i in arr) {
      if ('Status' in arr[i] && arr[i].Status === Status) { occurs++; }
    }
    return occurs;
    console.log(occurs);
  }
}
