import { Component, OnInit } from '@angular/core';
import { ExampleService } from '../example.service';

@Component({
  selector: 'app-task',
  templateUrl: './task.component.html',
  styleUrls: ['./task.component.scss']
})
export class TaskComponent implements OnInit {
  ticket: [];
  constructor(private example: ExampleService) { }

  ngOnInit() {
    this.example.getTickets()
      .subscribe(data => {
        this.ticket = data;
      });
    // console.log(this.ticket);
  }

}
