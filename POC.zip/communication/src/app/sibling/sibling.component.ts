import { Component, OnInit } from '@angular/core';


@Component({
  selector: 'app-sibling',
  templateUrl: './sibling.component.html',
  styleUrls: ['./sibling.component.scss']
})
export class SiblingComponent implements OnInit {
  message: string;
  constructor( ) { }

  ngOnInit() {
  }

}
