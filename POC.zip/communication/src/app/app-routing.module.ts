import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import {ParentComponent} from './parent/parent.component';
import {ChildComponent} from './child/child.component';
import {SiblingComponent} from './sibling/sibling.component';

const routes: Routes = [
  {path: 'parent', component: ParentComponent},
  {path: 'child', component: ChildComponent},
  {path: 'sibling', component: SiblingComponent},
  {path: '', redirectTo: '/parent', pathMatch: 'full'},
  {path: '**', component: ChildComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
