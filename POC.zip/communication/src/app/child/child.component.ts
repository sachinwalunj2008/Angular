import {Component, OnInit, Output, EventEmitter} from '@angular/core';
import {FormBuilder, FormControl, FormGroup, Validators} from '@angular/forms';
import {Router} from '@angular/router';

@Component({
  selector: 'app-child',
  templateUrl: './child.component.html',
  styleUrls: ['./child.component.scss']
})
export class ChildComponent implements OnInit {

  private myform: FormGroup;
  constructor( private router: Router) { }

  ngOnInit() {
    this.myform = new FormGroup({
      firstname: new FormControl( {value: '' , disabled: true}),
      lastname: new FormControl({ value: '', disabled: true})
    });
  }

  editEnable() {
    this.myform.controls.firstname.enable();
    this.myform.controls.lastname.enable();
  }

  gottolist() {
    this.router.navigate(['/parent']);
  }
}
